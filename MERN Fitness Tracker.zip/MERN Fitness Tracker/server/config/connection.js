const mongoose = require("mongoose");

mongoose.set("strictQuery", false);

mongoose.connect(
 "mongodb+srv://Ecommerce2024:Ecommerce2024@cluster0.ogkuxjs.mongodb.net/",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  },
  (err) => {
    if (err) throw err;
    console.log("Connected to MongoDB!");
  }
);

module.exports = mongoose.connection;
